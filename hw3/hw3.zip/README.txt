Liam Kolber
CSCI 4229
Homework 3
Due: September 28, 2017
--------------------------------------
   KEYS 	|		Description
--------------------------------------
Left/Right 	|	Rotate view around x-axis

  Up/Down 	|	Rotate view around y-axis

     A/a 	|	Toggle axes
--------------------------------------
Time to complete: 9 hours scattered over 4 days.

I edited the glut objects. Ignore the stuff about the millenium falcon. That is something I'm testing out for later use.