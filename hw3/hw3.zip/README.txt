Liam Kolber
CSCI 4229
Homework 3
Due: September 28, 2017
--------------------------------------
   KEYS 	|		Description
--------------------------------------
Left/Right 	|	Rotate view around x-axis

  Up/Down 	|	Rotate view around y-axis

     A/a 	|	Toggle axes
--------------------------------------
Time to complete: 9 hours scattered over 4 days.