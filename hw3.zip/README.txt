Liam Kolber
CSCI 4229
Homework 3
Due: September 28, 2017
--------------------------------------
   KEYS 			Description
--------------------------------------
Left/Right 	|	Rotate view around x-axis

  Up/Down 	|	Rotate view around y-axis

     a 		|	Toggle axes
--------------------------------------
Time to complete: 4 hours over 3 days.