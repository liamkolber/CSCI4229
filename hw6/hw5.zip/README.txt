Liam Kolber
CSCI 4229
Homework 4
Due: October 5, 2017
------------------------------------------
   KEYS 	|		  Description
------------------------------------------
Left/Right 	|	Rotate view around x-axis

  Up/Down 	|	Rotate view around y-axis

Page Up/Down| 	Increase/decrease dim

     0   	|	Reset viewing angle

     9		|	Toggle axes

    1/2		|	Decrease/increase FOV

    m/M 	|	Change mode

    f/F 	|	Toggle first person view

    w/W 	|	Forward

    s/S 	|	Backward

    a/A 	|	Look left

    d/D 	| 	Look right

   SPACE    |   Start/stop light movement

    </>     |   Horizontal light movement

    u/i     |   Vertical light movement	
------------------------------------------
Time to complete: ~5 hours