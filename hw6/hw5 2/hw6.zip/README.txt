Liam Kolber
CSCI 4229
Homework 6
Due: October 26, 2017
------------------------------------------
   KEYS   	|		  Description
------------------------------------------
Left/Right 	|	Rotate view around x-axis

  Up/Down 	|	Rotate view around y-axis

Page Up/Down| Increase/decrease dim

     0    	|	Reset viewing angle

     9	   	|	Toggle axes

    1/2		  |	Decrease/increase FOV

    m/M 	  |	Change mode

    f/F 	  |	Toggle first person view

    w/W 	  |	Forward

    s/S 	  |	Backward

    a/A 	  |	Look left

    d/D 	  | Look right

   SPACE    | Start/stop light movement

    </>     | Horizontal light movement

    u/i     | Vertical light movement	
------------------------------------------
Time to complete: ~6 hours




Reasons for untextured areas:
-----------------------------
The untextured areas are the tops of the smoke stacks, the bottom of the main body, and the sides of the tracks cylinder.
The smoke stacks are untextured because in real life, that area is almost exclusively black anyway, so I figured I would just color it by hand.
For the bottom of the main body, this is an area that is pretty difficult to see, and it would be dark due to shadows anyway, so I figured I would just leave it black as well.
Finally, the sides of the tracks cylinder are left blank to appear as if that section of track was removed from the earth like a puzzle piece. It's supposed to seem as if there are more sections to add. If that makes any sense.